package user;

public class ExistedUserException extends Exception {
	private static final long serialVersionUID = 1L;

	public ExistedUserException() {
		super();
	}

	public ExistedUserException(String arg0) {
		super(arg0);
	}
}
