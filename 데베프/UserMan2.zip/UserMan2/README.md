# UserMan2
Sample project for DBP class
based on MVC architecture 

__Branches__
 
- master <span style="color:blue">(default)</span>
- update(UserMan2u) - integrates update controllers
  
### Eclipse에서 local repository를 생성하고 project를 import하는 방법 
(주의: 먼저 Github(<https://github.com>)에 로그인한 후 본 리파지토리(<https://github.com/cspark0/UserMan2>)에 접속해서 우측 상단의 Fork 버튼을 이용하여 본인의 계정으로 복제함)

1. File 메뉴 > Import... > Git | Projects from Git (with smart import) 
2. Clone URI 
3. fork된  URI 입력(예: https://github.com/your_Github_username/UserMan2.git), user & password 값 입력 
4. master branch 선택 (또는 모든 branch 선택)
5. 생성할 local repository 경로 확인 (예: C:\Users\사용자\git\UserMan2) 
6. 다음 화면(Imports project ...)에서 Finish
7. 프로젝트가 import되었는지 확인하고 프로젝트가 빌드 완료될 때까지 기다림
8. 오류가 표시되어 있으면 Maven > Update project.. 실행 (Alt+F5)


### 참고: Git 사용법 

- 윤웅식, 만들면서 배우는 Git+GitHub 입문, 한빛미디어, 2015.  
- 오오츠카 히로키, 소셜 코딩으로 이끄는 GitHub 실천 기술, 제이펍, 2015.  
- <https://backlog.com/git-tutorial/kr/>  
- <https://nolboo.kim/blog/2013/10/06/github-for-beginner/> 및 링크된 문서들  
- <http://itmir.tistory.com/461>  
- <http://jwgye.tistory.com/38?category=689862>  
- 온라인 자료들
