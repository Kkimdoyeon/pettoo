package ddwu.com.mobile.openapitest.data

data class Movie(
    var rank: Int?,
    var title: String?,
    var openDate: String?
)

